Place any Winamp (input, DSP, visualiser) plugins and any MusicBee plugins (http://getmusicbee.com/forum/index.php?board=10.0) in this folder
